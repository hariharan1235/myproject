import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="votedata"
)
Steve=request.form('Steve');
Elon=request.form('Elon');
Bill=request.form('Bill');
Jeff=request.form('Jeff');

mycursor = mydb.cursor()

mycursor.execute("SELECT * FROM votelist");
myresult=mycursor.fetchall();

sql = "UPDATE votelist SET address = steve WHERE address = Steve+row[0]"
sql = "UPDATE votelist SET address = elon WHERE address = Elon+row[1]"
sql = "UPDATE votelist SET address = bill WHERE address = Bill+row[2]"
sql = "UPDATE votelist SET address = jeff WHERE address = Jeff+row[3]"


mycursor.execute(sql)

mydb.commit()

print(mycursor.rowcount, "Vote successful.")