from flask import Flask, render_template
import mysql.connector

mydatabase = mysql.connector.connect(
    host = 'localhost(or any other host)', user = 'root',
    passwd = '', database = 'vote')


mycursor = mydatabase.cursor()


@app.route('after_admin_login.html')
def example():
   mycursor.execute('SELECT * FROM votelist')
   data = mycursor.fetchall()
   return render_template('after_admin_login.html', output_data = data)




