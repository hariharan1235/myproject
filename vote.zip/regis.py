import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="candidatelogin"
)
email=request.form('email');
passw=request.form('password');
mycursor = mydb.cursor()

sql = "INSERT INTO usertable (email , password) VALUES (%s, %s)"
val = (email, passw)

mycursor.execute(sql, val)

mydb.commit()

print(mycursor.rowcount, "Register successful.")