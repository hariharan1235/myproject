import mysql.connector
u=request.form('email');
p=request.form('password');
conn=mysql.connector.connect(host="localhost",user="root",password="",database="candidatelogin")
cursor=conn.cursor()
sq="select * from userlogin"
cursor.execute(sq)
records=cursor.fetchall()
for i in records:
    k=i[0]
    v=i[1]
if u==k:
    if p==v:
        print("Login successful")
        open("afterlogin.html");
    else:
        print("password wrong")
else:
    print("username wrong")