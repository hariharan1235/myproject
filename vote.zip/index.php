<!DOCTYPE html>
<html>
<head>
	<title>Voting</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<nav>
	<div id="A">
		<h1>VOTE</h1>
	</div>
	<div id="B">
	<ul>
		<li><a href="index.php"><i class="fa fa-home"></i> HOME</a></li>
		<li><a href="index.php">USER LOGIN</a></li>
		<li><a href="admin_login.html">ADMIN LOGIN</a></li>
	</ul>
	</div>
</nav>
<div class="login">
	<div class="button_box">
		<div id="btn"></div>
		<button type="button" class="toggle_btn" onclick="candidate()">LOGIN</button>
	    <button type="button" class="toggle_btn" onclick="admin()">REGISTER</button>
	</div>
    <form  method="post" action="valid.py" id="candidate" class="input">
    	<input type="text" class="input-field" placeholder="Email ID" >
    	<input type="Password" class="input-field" placeholder="Password" >
    	<br><br>
    	<button type="submit" class="submit_btn">LOGIN</button>
    </form>
    <form  method="post" action="regis.py" id="admin" class="input">
    	<input name="email" type="text" class="input-field" placeholder="Email ID" >
    	<input name="password" type="Password" class="input-field" placeholder="Password" >
    	<br><br>
    	<button type="submit" class="submit_btn">REGISTER</button>
    </form>


	
</div>

	<script>
		var x=document.getElementById("candidate");
		var y=document.getElementById("admin");
		var z=document.getElementById("btn");
		function admin() 
		{
			x.style.left="-400px";
			y.style.left="50px";
			z.style.left="160px";
		}
		function candidate() 
		{
			x.style.left="50px";
			y.style.left="450px";
			z.style.left="0px";
		}
	</script>

</body>
</html>